import { Component } from '@angular/core';
import { NodeutilityService } from '../nodeutility.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-changepwd',
  templateUrl: './changepwd.component.html',
  styleUrl: './changepwd.component.css'
})
export class ChangepwdComponent {
  constructor(private util:NodeutilityService,private router:Router) { }
  
  msg:string='';

  onSubmit(form: any) {
    this.util.update(form.value.email, form.value.oldpw,form.value.newpw).subscribe((data) => {
        if (data.status) {
          this.msg = data.message;
        }
        else{
          this.msg = data.message;
        }
      });
}

}
