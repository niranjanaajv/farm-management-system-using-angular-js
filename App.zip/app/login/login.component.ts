import { Component } from '@angular/core';
import { NodeutilityService } from '../nodeutility.service';
import { Router } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  msg:string="";
  user:string | null="";
  constructor(private util:NodeutilityService,private router:Router) { }
  
  onSubmit(form: any) {
    this.util.insert(form.value.email, form.value.pw).subscribe((data) => {
        if (data.status){
          localStorage.setItem("user",form.value.email);
          this.msg = data.message;
          alert(this.msg);
          this.router.navigate(['/mainhome']);
        }
      
        else{
          this.msg = data.message;
          alert(this.msg);
          this.router.navigate(['/login']);
        }
        
      });
  }
}
