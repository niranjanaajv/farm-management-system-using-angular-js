import { Component } from '@angular/core';

@Component({
  selector: 'app-pumpkin',
  templateUrl: './pumpkin.component.html',
  styleUrl: './pumpkin.component.css'
})
export class PumpkinComponent {

}
