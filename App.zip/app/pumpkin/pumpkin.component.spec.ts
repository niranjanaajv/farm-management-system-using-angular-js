import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PumpkinComponent } from './pumpkin.component';

describe('PumpkinComponent', () => {
  let component: PumpkinComponent;
  let fixture: ComponentFixture<PumpkinComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PumpkinComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PumpkinComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
