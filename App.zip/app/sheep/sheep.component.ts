import { Component } from '@angular/core';

@Component({
  selector: 'app-sheep',
  templateUrl: './sheep.component.html',
  styleUrl: './sheep.component.css'
})
export class SheepComponent {

}
