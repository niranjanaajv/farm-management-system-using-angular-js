import { Component } from '@angular/core';

@Component({
  selector: 'app-goat',
  templateUrl: './goat.component.html',
  styleUrl: './goat.component.css'
})
export class GoatComponent {

}
