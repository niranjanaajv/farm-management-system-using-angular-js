import { Component } from '@angular/core';

@Component({
  selector: 'app-cabbage',
  templateUrl: './cabbage.component.html',
  styleUrl: './cabbage.component.css'
})
export class CabbageComponent {

}
