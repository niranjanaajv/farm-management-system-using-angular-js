import { Component } from '@angular/core';
import { NodeutilityService } from '../nodeutility.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrl: './signup.component.css'
})
export class SignupComponent {
  constructor(private util:NodeutilityService,private router:Router){}
  imageUrl='../../assets/Reg.jpg';
  msg:string="";
  uname:string="";
  selectedGender:string="";
  onSubmit(form: any) {
    this.util.insert1(form.value.fname, form.value.uname, form.value.pno,form.value.email, form.value.pwd).subscribe((data) => {
        if (data.status) 
          this.msg = data.message;
        else{
          this.msg = data.message;
        }
        if(data.status){
          this.router.navigate(['/login']);
        }
      });
    }



    printError(Id: string, Msg: string) {
      const element = document.getElementById(Id);
      if (element) {
        element.innerHTML = Msg;
      }
    }
  
    validateForm() {
      const fnameElement = <HTMLInputElement>document.querySelector("#fname");
      const unameElement = <HTMLInputElement>document.querySelector("#uname");
      const emailElement = <HTMLInputElement>document.querySelector("#email");
      const mobileElement = <HTMLInputElement>document.querySelector("#pno");
      const pwElement = <HTMLInputElement>document.querySelector("#pwd");
      const cpwElement = <HTMLInputElement>document.querySelector("#cpwd");
      const genderElement = <HTMLInputElement>document.querySelector("#gender");
      
      
  
      if (!fnameElement || !unameElement|| !emailElement || !mobileElement ||!pwElement || !cpwElement || !genderElement) {
        return false; // Return false if any required element is missing
      }
  
      const fname = fnameElement.value;
      const uname = unameElement.value;
      const email = emailElement.value;
      const mobile = mobileElement.value;
      const pw = pwElement.value;
      const cpw = cpwElement.value;
      const gender = genderElement.value;
  
      let fnameErr: boolean = true, unameErr: boolean = true, emailErr: boolean = true, mobileErr: boolean = true ,pwErr:boolean=true, cpwErr: boolean = true, genderErr: boolean = true;
  
      if (fname == "") {
        this.printError("fnameErr", "Please enter your name");
        fnameElement.classList.add("input-2");
        fnameElement.classList.remove("input-1");
      } else {
        const regex = /^[a-zA-Z\s]+$/;
        if (regex.test(fname) === false) {
          this.printError("fnameErr", "Please enter a valid name");
          fnameElement.classList.add("input-2");
          fnameElement.classList.remove("input-1");
        } else {
          this.printError("fnameErr", "");
          fnameErr = false;
          fnameElement.classList.add("input-1");
          fnameElement.classList.remove("input-2");
        }
      }

      if (uname == "") {
        this.printError("unameErr", "Please enter user name");
        unameElement.classList.add("input-2");
        unameElement.classList.remove("input-1");
      } else {
        const regex = /^[a-zA-Z0-9\s]+$/;
        if (regex.test(uname) === false) {
          this.printError("unameErr", "Please enter a valid user name");
          unameElement.classList.add("input-2");
          unameElement.classList.remove("input-1");
        } else {
          this.printError("unameErr", "");
          unameErr = false;
          unameElement.classList.add("input-1");
          unameElement.classList.remove("input-2");
        }
      }
  
      if (email == "") {
        this.printError("emailErr", "Please enter your email address");
        emailElement.classList.add("input-2");
        emailElement.classList.remove("input-1");
      } else {
        var regex = /^\S+@\S+\.\S+$/;
        if (regex.test(email) === false) {
          this.printError("emailErr", "Please enter a valid email address");
          emailElement.classList.add("input-2");
          emailElement.classList.remove("input-1");
        } else {
          this.printError("emailErr", "");
          emailErr = false;
          emailElement.classList.add("input-1");
          emailElement.classList.remove("input-2");
        }
      }
  
      if (mobile == "") {
        this.printError("mobileErr", "Please enter your mobile number");
        mobileElement.classList.add("input-2");
        mobileElement.classList.remove("input-1");
      } else {
        var regex = /^[1-9]\d{9}$/;
        if (regex.test(mobile) === false) {
          this.printError("mobileErr", "Please enter a valid 10 digit mobile number");
          mobileElement.classList.add("input-2");
          mobileElement.classList.remove("input-1");
        } else {
          this.printError("mobileErr", "");
          mobileErr = false;
          mobileElement.classList.add("input-1");
          mobileElement.classList.remove("input-2");
        }
      }
  
      
      if(pw == ""){
        this.printError("pwErr","Please enter your password");
        pwElement.classList.add("input-4");
        pwElement.classList.remove("input-3");
      } else {
        this.printError("pwErr", "");
        pwErr = false;
        pwElement.classList.add("input-3");
        pwElement.classList.remove("input-4");
      }

      if(cpw == ""){
        this.printError("cpwErr","Please enter your password ");
        cpwElement.classList.add("input-4");
        cpwElement.classList.remove("input-3");
      } else {
        if(pw!=cpw){
          this.printError("cpwErr","password and confirm password does not match");
          emailElement.classList.add("input-2");
          emailElement.classList.remove("input-1");
        }
        else{
          this.printError("cpwErr", "");
          cpwErr = false;
          cpwElement.classList.add("input-3");
          cpwElement.classList.remove("input-4");
        }
        
      }

      if (gender == "") {
        this.printError("genderErr", "Please select your gender");
        genderElement.classList.add("input-4");
        genderElement.classList.remove("input-3");
      } else {
        this.printError("genderErr", "");
        genderErr = false;
        genderElement.classList.add("input-3");
        genderElement.classList.remove("input-4");
      }

      
      
  
    
    
  
      // Repeat the same pattern for other form fields...
  
      if (fnameErr ||unameErr || emailErr || mobileErr || pwErr || cpwErr) {
        return false;
      }
      return true;
    }
      
        
    }
  
    