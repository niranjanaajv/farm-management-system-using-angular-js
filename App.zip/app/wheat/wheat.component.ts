import { Component } from '@angular/core';

@Component({
  selector: 'app-wheat',
  templateUrl: './wheat.component.html',
  styleUrl: './wheat.component.css'
})
export class WheatComponent {

}
