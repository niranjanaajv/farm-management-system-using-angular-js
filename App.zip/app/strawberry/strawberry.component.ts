import { Component } from '@angular/core';

@Component({
  selector: 'app-strawberry',
  templateUrl: './strawberry.component.html',
  styleUrl: './strawberry.component.css'
})
export class StrawberryComponent {

}
