import { Component } from '@angular/core';

@Component({
  selector: 'app-cock',
  templateUrl: './cock.component.html',
  styleUrl: './cock.component.css'
})
export class CockComponent {

}
