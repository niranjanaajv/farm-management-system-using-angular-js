import { Component } from '@angular/core';

@Component({
  selector: 'app-cattles',
  templateUrl: './cattles.component.html',
  styleUrl: './cattles.component.css'
})
export class CattlesComponent {

}
