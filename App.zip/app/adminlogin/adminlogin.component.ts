import { Component } from '@angular/core';
import { NodeutilityService } from '../nodeutility.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrl: './adminlogin.component.css'
})
export class AdminloginComponent {
  msg:string="";
 
 
  user1:string | null="";
  constructor(private util:NodeutilityService,private router:Router){

  }
 
  onSubmit(form: any) {
    this.util.insert2(form.value.email, form.value.pw).subscribe((data) => {
        if (data.status){
          localStorage.setItem("user1",form.value.email);
          this.msg = data.message;
          alert(this.msg);
          this.router.navigate(['/adminhome']);

          
        }
      
        else{
          this.msg = data.message;
        }
        
      });
  }
}
