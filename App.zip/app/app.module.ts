import { NgModule } from '@angular/core';
import { BrowserModule} from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { HomeComponent } from './home/home.component';
import { CropsComponent } from './crops/crops.component';
import { CattlesComponent } from './cattles/cattles.component';
import { ShoppingCartComponent } from './shopping-cart/shopping-cart.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule} from '@angular/common/http';

import { NodeutilityService } from './nodeutility.service';
import { PayComponent } from './pay/pay.component';
import { TickComponent } from './tick/tick.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { DeleteComponent } from './delete/delete.component';
import { ChangepwdComponent } from './changepwd/changepwd.component';
import { MainhomeComponent } from './mainhome/mainhome.component';
import { ItemsComponent } from './items/items.component';
import { UpdateitemComponent } from './updateitem/updateitem.component';
import { DeleteitemComponent } from './deleteitem/deleteitem.component';
import { CockComponent } from './cock/cock.component';
import { CowComponent } from './cow/cow.component';
import { DuckComponent } from './duck/duck.component';
import { GoatComponent } from './goat/goat.component';
import { HenComponent } from './hen/hen.component';
import { SheepComponent } from './sheep/sheep.component';
import { CabbageComponent } from './cabbage/cabbage.component';
import { CarrotComponent } from './carrot/carrot.component';
import { GrapesComponent } from './grapes/grapes.component';
import { PlumComponent } from './plum/plum.component';
import { PumpkinComponent } from './pumpkin/pumpkin.component';
import { RiceComponent } from './rice/rice.component';
import { SpinachComponent } from './spinach/spinach.component';
import { StrawberryComponent } from './strawberry/strawberry.component';
import { WheatComponent } from './wheat/wheat.component';
import { DisplayComponent } from './display/display.component';
import { AboutComponent } from './about/about.component';
import { ReviewComponent } from './review/review.component';
import { ViewreviewComponent } from './viewreview/viewreview.component';
import { ItemslistComponent } from './itemslist/itemslist.component';
import { PaymentComponent } from './payment/payment.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignupComponent,
    HomeComponent,
    CropsComponent,
    CattlesComponent,
    ShoppingCartComponent,
  
    PayComponent,
    TickComponent,
    AdminloginComponent,
    AdminhomeComponent,
    DeleteComponent,
    ChangepwdComponent,
    MainhomeComponent,
    ItemsComponent,
    UpdateitemComponent,
    DeleteitemComponent,
    CockComponent,
    CowComponent,
    DuckComponent,
    GoatComponent,
    HenComponent,
    SheepComponent,
    CabbageComponent,
    CarrotComponent,
    GrapesComponent,
    PlumComponent,
    PumpkinComponent,
    RiceComponent,
    SpinachComponent,
    StrawberryComponent,
    WheatComponent,
    DisplayComponent,
  
    AboutComponent,
    ReviewComponent,
    ViewreviewComponent,
    ItemslistComponent,
    PaymentComponent,
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
  ],
  providers: [
    NodeutilityService,
    ShoppingCartComponent,
    
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
