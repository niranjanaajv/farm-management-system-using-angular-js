import { Component } from '@angular/core';

@Component({
  selector: 'app-duck',
  templateUrl: './duck.component.html',
  styleUrl: './duck.component.css'
})
export class DuckComponent {

}
