import { Component } from '@angular/core';

@Component({
  selector: 'app-cow',
  templateUrl: './cow.component.html',
  styleUrl: './cow.component.css'
})
export class CowComponent {

}
