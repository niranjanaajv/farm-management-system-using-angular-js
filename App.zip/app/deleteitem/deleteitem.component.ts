import { Component } from '@angular/core';
import { NodeutilityService } from '../nodeutility.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-deleteitem',
  templateUrl: './deleteitem.component.html',
  styleUrl: './deleteitem.component.css'
})
export class DeleteitemComponent {
  item:string='';
  quantity:string="";
  msg:string="";
  constructor(private util:NodeutilityService,private router:Router) { }
  delete(){
    this.util.delete1(this.item,this.quantity).subscribe((data)=>{
      if(data.status){
        this.msg=data.message;
      }
      else{
        this.msg=data.message;
      }
    });
  }

}
