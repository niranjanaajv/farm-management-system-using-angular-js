import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PlumComponent } from './plum.component';

describe('PlumComponent', () => {
  let component: PlumComponent;
  let fixture: ComponentFixture<PlumComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PlumComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PlumComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
