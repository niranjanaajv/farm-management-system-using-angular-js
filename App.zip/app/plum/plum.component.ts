import { Component } from '@angular/core';

@Component({
  selector: 'app-plum',
  templateUrl: './plum.component.html',
  styleUrl: './plum.component.css'
})
export class PlumComponent {

}
