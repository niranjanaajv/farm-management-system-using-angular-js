import { Component } from '@angular/core';

@Component({
  selector: 'app-adminhome',
  templateUrl: './adminhome.component.html',
  styleUrl: './adminhome.component.css'
})
export class AdminhomeComponent {
  user1: string | null = '';

  logout() : void{
    if (this.user1 != null) {
      localStorage.removeItem('user1');
    }
  
  }

  ngOnInit(): void {
    // Retrieve the 'user' value from local storage
    this.user1 = localStorage.getItem('user1');
  }
}
