import { Component } from '@angular/core';

@Component({
  selector: 'app-crops',
  templateUrl: './crops.component.html',
  styleUrl: './crops.component.css'
})
export class CropsComponent {

}
