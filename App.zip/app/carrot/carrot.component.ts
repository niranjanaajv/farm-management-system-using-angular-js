import { Component } from '@angular/core';

@Component({
  selector: 'app-carrot',
  templateUrl: './carrot.component.html',
  styleUrl: './carrot.component.css'
})
export class CarrotComponent {

}
