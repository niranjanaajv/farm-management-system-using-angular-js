import { Component } from '@angular/core';

@Component({
  selector: 'app-hen',
  templateUrl: './hen.component.html',
  styleUrl: './hen.component.css'
})
export class HenComponent {

}
