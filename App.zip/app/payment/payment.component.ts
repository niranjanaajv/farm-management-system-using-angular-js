import { Component } from '@angular/core';
import { NodeutilityService } from '../nodeutility.service';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrl: './payment.component.css'
})
export class PaymentComponent {
  msg:string="";
  sList:any[]=[];
  constructor(private util:NodeutilityService){
    this.display4();
  }

  display4() {
    this.util.display4().subscribe((data) => {
      if (data.status) {
        this.sList = data.list;
      }
      this.msg = data.message;
    });
  }
}
