import { Component } from '@angular/core';
import { NodeutilityService } from '../nodeutility.service';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrl: './display.component.css'
})
export class DisplayComponent {
  msg:string="";
  sList:any[]=[];
  constructor(private util:NodeutilityService){
		this.display();
	}

  display() {
    this.util.display().subscribe((data) => {
      if (data.status) {
        this.sList = data.list;
      }
      this.msg = data.message;
    });
  }
}
