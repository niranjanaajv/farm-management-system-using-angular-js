import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { CattlesComponent } from './cattles/cattles.component';
import { CropsComponent } from './crops/crops.component';
import { ShoppingCartComponent } from './shopping-cart/shopping-cart.component';
import { PayComponent } from './pay/pay.component';
import { TickComponent } from './tick/tick.component';

import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { DeleteComponent } from './delete/delete.component';
import { ChangepwdComponent } from './changepwd/changepwd.component';
import { ItemsComponent } from './items/items.component';
import { UpdateitemComponent } from './updateitem/updateitem.component';
import { DeleteitemComponent } from './deleteitem/deleteitem.component';
import { CockComponent } from './cock/cock.component';
import { CowComponent } from './cow/cow.component';
import { DuckComponent } from './duck/duck.component';
import { GoatComponent } from './goat/goat.component';
import { HenComponent } from './hen/hen.component';
import { SheepComponent } from './sheep/sheep.component';
import { CabbageComponent } from './cabbage/cabbage.component';
import { CarrotComponent } from './carrot/carrot.component';
import { GrapesComponent } from './grapes/grapes.component';
import { PlumComponent } from './plum/plum.component';
import { PumpkinComponent } from './pumpkin/pumpkin.component';
import { RiceComponent } from './rice/rice.component';
import { StrawberryComponent } from './strawberry/strawberry.component';
import { SpinachComponent } from './spinach/spinach.component';
import { DisplayComponent } from './display/display.component';
import { WheatComponent } from './wheat/wheat.component';
import { MainhomeComponent } from './mainhome/mainhome.component';
import { AboutComponent } from './about/about.component';
import { ReviewComponent } from './review/review.component';
import { ViewreviewComponent } from './viewreview/viewreview.component';
import { ItemslistComponent } from './itemslist/itemslist.component';
import { PaymentComponent } from './payment/payment.component';



const routes: Routes = [
  {path:'',redirectTo:'/home',pathMatch:'full'},
  {path:"home",component:HomeComponent},
  {path:"login",component:LoginComponent},
  {path:"signup",component:SignupComponent},
  {path:"crops",component:CropsComponent},
  {path:"cattles",component:CattlesComponent},
  {path:"shopping-cart",component:ShoppingCartComponent},
  {path:"pay",component:PayComponent},
  {path:"tick",component:TickComponent},
  {path:"review",component:ReviewComponent},
  {path:"adminlogin",component:AdminloginComponent},
  {path:"adminhome",component:AdminhomeComponent},
  {path:"delete",component:DeleteComponent},
  {path:"changepwd",component:ChangepwdComponent},
  {path:"items",component:ItemsComponent},
  {path:"updateitem",component:UpdateitemComponent},
  {path:"deleteitem",component:DeleteitemComponent},
  {path:"cock",component:CockComponent},
  {path:"cow",component:CowComponent},
  {path:"duck",component:DuckComponent},
  {path:"goat",component:GoatComponent},
  {path:"hen",component:HenComponent},
  {path:"sheep",component:SheepComponent},
  {path:"cabbage",component:CabbageComponent},
  {path:"carrot",component:CarrotComponent},
  {path:"grapes",component:GrapesComponent},
  {path:"plum",component:PlumComponent},
  {path:"pumpkin",component:PumpkinComponent},
  {path:"rice",component:RiceComponent},
  {path:"strawberry",component:StrawberryComponent},
  {path:"spinach",component:SpinachComponent},
  {path:"wheat",component:WheatComponent},
  {path:"display", component:DisplayComponent},
  {path:"mainhome",component:MainhomeComponent},
  {path:"about",component:AboutComponent},
  {path:"itemslist",component:ItemslistComponent},
  {path:"viewreview",component:ViewreviewComponent},
  {path:"payment",component:PaymentComponent},

  {path:'**',redirectTo:'/home'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
