import { Component } from '@angular/core';

@Component({
  selector: 'app-spinach',
  templateUrl: './spinach.component.html',
  styleUrl: './spinach.component.css'
})
export class SpinachComponent {

}
