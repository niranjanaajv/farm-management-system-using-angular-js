import { Component } from '@angular/core';
import { NodeutilityService } from '../nodeutility.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-items',
  templateUrl: './items.component.html',
  styleUrl: './items.component.css'
})
export class ItemsComponent {
  constructor(private util:NodeutilityService,private router:Router) { }
  item:string='';
  quantity:string="";
  msg:string="";
  onSubmit(form: any) {
    this.util.insert3(form.value.item, form.value.quantity).subscribe((data) => {
        if (data.status) 
          this.msg = data.message;
        else{
          this.msg = data.message;
        }
        if(data.status){
          this.router.navigate(['/adminhome']);
        }
      });
    }


}
