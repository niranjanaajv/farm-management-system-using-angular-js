import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class NodeutilityService {

  constructor(private HttpClient:HttpClient) { }
  url:string="http://localhost:5000/";

  insert(email:string,pw:string):Observable<any>{
    return this.HttpClient.get(this.url+"insert?email="+email+"&pw="+pw);
  }
  insert1(fullname:string,username:string,phn:string,email:string,pw:string):Observable<any>{
    return this.HttpClient.get(this.url+"insert1?fname="+fullname+"&uname="+username+"&pno="+phn+"&email="+email+"&pwd="+pw);
  }
  insert2(email:string,pw:string):Observable<any>{
    return this.HttpClient.get(this.url+"insert2?email="+email+"&pw="+pw);
  }
  insert3(item:string,quantity:string):Observable<any>{
    return this.HttpClient.get(this.url+"insert3?item="+item+"&quantity="+quantity);
  }
  insert5(cardno:string,cn:string,validtill:string,cvv:string,total:string):Observable<any>{
    return this.HttpClient.get(this.url+"insert5?cardno="+cardno+"&cn="+cn+"&validtill="+validtill+"&cvv="+cvv+"&total="+total);
  }
  insert_prod(user:string,items:string,total:number):Observable<any>{
    return this.HttpClient.post(this.url + "insert_prod", { user,items, total });
  }

  
  delete(email:string,pw:string): Observable<any> {
    return this.HttpClient.get(this.url + "delete?email="+email+"&pw="+pw);  
  }
  insert4(email:string,reviewText:string,rating:number):Observable <any>{
    return this.HttpClient.get(this.url+"insert4?&email="+email+"&reviewText="+reviewText+"&rating="+rating);
  }


  delete1(item:string,quantity:string): Observable<any> {
    return this.HttpClient.get(this.url + "delete1?item="+item+"&quantity="+quantity);  
  }
  update(email: string, oldpw: string, newpw: string): Observable<any> {
    return this.HttpClient.get(this.url + "update?email=" + email  + "&oldpw=" + oldpw+ "&newpw=" + newpw);
}
update1(item: string, oldquantity: string, newquantity: string): Observable<any> {
  return this.HttpClient.get(this.url + "update1?item="+ item  + "&oldquantity=" + oldquantity+ "&newquantity=" + newquantity);
}

display():Observable<any>{
  return this.HttpClient.get(this.url+"findAll");
}
display3():Observable<any>{
  return this.HttpClient.get(this.url+"findAll3");
}
display2():Observable<any>{
  return this.HttpClient.get(this.url+"findAll2");
}
display4():Observable<any>{
  return this.HttpClient.get(this.url+"findAll4");
}

}
