import { Component } from '@angular/core';
import { NodeutilityService } from '../nodeutility.service';

@Component({
  selector: 'app-itemslist',
  templateUrl: './itemslist.component.html',
  styleUrl: './itemslist.component.css'
})
export class ItemslistComponent {
  msg:string="";
  sList:any[]=[];
  constructor(private util:NodeutilityService){
    this.display3();
  }

  display3() {
    this.util.display3().subscribe((data) => {
      if (data.status) {
        this.sList = data.list;
      }
      this.msg = data.message;
    });
  }

}
