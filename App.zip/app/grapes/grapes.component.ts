import { Component } from '@angular/core';

@Component({
  selector: 'app-grapes',
  templateUrl: './grapes.component.html',
  styleUrl: './grapes.component.css'
})
export class GrapesComponent {

}
