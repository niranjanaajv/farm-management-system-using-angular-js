import { Component } from '@angular/core';

@Component({
  selector: 'app-rice',
  templateUrl: './rice.component.html',
  styleUrl: './rice.component.css'
})
export class RiceComponent {

}
