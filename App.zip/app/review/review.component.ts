import { Component } from '@angular/core';
import { NodeutilityService } from '../nodeutility.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-review',
  templateUrl: './review.component.html',
  styleUrl: './review.component.css'
})
export class ReviewComponent {
  ngOnInit(): void {
  }

  rating: number = 0;
  stars: number[] = [1, 2, 3, 4, 5];
  reviewText: string = ''; // Add a property to hold the review text

  rate(rating: number) {
    this.rating = rating;
    console.log('Rating:', this.rating);
  }
  constructor(private util: NodeutilityService, private router: Router) {}
  msg: string = '';
  submitReview(form:any) {
    // Here you can implement the logic to submit the review
    console.log('Review Rating:', this.rating);
    console.log('Review Text:', this.reviewText);
    
    this.util.insert4(form.value.email,form.value.reviewText,this.rating).subscribe((data) => {
      if (data.status) {
        this.msg = data.message;
      }
    });
    // Clear the review text after submission if needed
    this.reviewText = '';
    this.rating = 0;
    // You can also perform additional actions such as sending the review to a backend API
  }

}
