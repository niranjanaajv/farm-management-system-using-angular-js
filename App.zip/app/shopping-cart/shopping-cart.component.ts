import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { NodeutilityService } from '../nodeutility.service';
import { Injectable } from '@angular/core';

export interface Product {
  id: number;
  name: string;
  price: number;
  imageUrl: string; // Add this property
}
@Injectable({
  providedIn:'root'
})

@Component({
  selector: 'app-shopping-cart',
  templateUrl: './shopping-cart.component.html',
  styleUrl: './shopping-cart.component.css'
})
export class ShoppingCartComponent {
  user: string | null = '';
  total:number=0;
  username:string | null = '';

  logout() : void{
    if (this.user != null) {
      localStorage.removeItem('user');
      //this.router.navigate(['/home']);
    }
  
  }

  ngOnInit(): void {
    // Retrieve the 'user' value from local storage
    this.user = localStorage.getItem('user');
    if(this.user==null)
      {
        this.router.navigate(['/home']);
      }
      if (this.user) {
        const atIndex = this.user.indexOf('@'); // Find the index of '@' symbol
        if (atIndex !== -1) {
          this.username = this.user.substring(0, atIndex); // Extract the substring before '@'
        }
      }
  }
  cart: Product[] = [];

  products: Product[] = [
    { id: 1, name: 'brinjal', price: 50, imageUrl: '../../assets/shopproducts/brinjal.jpg' },
    { id: 2, name: 'carrot', price: 50, imageUrl: '../../assets/shopproducts/carrot.jpg' },
    { id: 3, name: 'corn', price: 30, imageUrl: '../../assets/shopproducts/corn.jpg' },
    { id: 4, name: 'fertilizer', price: 30, imageUrl: '../../assets/shopproducts/fertilizer.jpg' },
    { id: 5, name: 'honey', price: 30, imageUrl: '../../assets/shopproducts/honey.jpg' },
    { id: 6, name: 'milk', price: 30, imageUrl: '../../assets/shopproducts/milk.jpg' },
    { id: 37, name: 'rice', price: 30, imageUrl: '../../assets/shopproducts/rice.jpg' },
];

  constructor(private router: Router) {}
  msg:string='';
  

  addToCart(product: Product): void {
    this.cart.push(product);

  }

  removeFromCart(product: Product): void {
    const index = this.cart.findIndex(p => p.id === product.id);
    if (index !== -1) {
      this.cart.splice(index, 1);
    }
  }

  getTotal(): number {
    this.total= this.cart.reduce((total, product) => total + product.price, 0);
    return this.total;
  }

  checkout(): void {
    // Perform checkout logic here
    // For demonstration purposes, navigate to the payment page
    const quantity = this.cart.length; 
    if (quantity < 1 || !Number.isInteger(quantity)) {
      alert('Please enter a valid quantity.');
      return;
    }
    else{
      if(this.user){
        this.total = this.getTotal();
      localStorage.setItem("total", JSON.stringify(this.total));
      const allItems = this.cart.map(item => ({
        name: item.name,
        price: item.price
      }));
      localStorage.setItem("items",JSON.stringify(allItems));
      
      localStorage.setItem("user1",this.user);
      this.router.navigate(['/pay']);
      }
}
}
  
  }
  

