import { Component } from '@angular/core';
import { NodeutilityService } from '../nodeutility.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-updateitem',
  templateUrl: './updateitem.component.html',
  styleUrl: './updateitem.component.css'
})
export class UpdateitemComponent {
  constructor(private util:NodeutilityService,private router:Router) { 
    this.display3();
  }
  
  msg:string='';
  sList:any[]=[];

  onSubmit(form: any) {
    this.util.update1(form.value.item, form.value.oldquantity,form.value.newquantity).subscribe((data) => {
        if (data.status) {
          this.msg = data.message;
        }
        else{
          this.msg = data.message;
        }
      });
}


display3() {
  this.util.display3().subscribe((data) => {
    if (data.status) {
      this.sList = data.list;
    }
    this.msg = data.message;
  });
}
}
