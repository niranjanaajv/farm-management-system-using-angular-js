import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-mainhome',
  templateUrl: './mainhome.component.html',
  styleUrl: './mainhome.component.css'
})
export class MainhomeComponent {
  user: string | null = '';
  constructor(private router: Router) {}
  logout() : void{
    if (this.user != null) {
      localStorage.removeItem('user');
      
    }
  
  }

  ngOnInit(): void {
    // Retrieve the 'user' value from local storage
    this.user = localStorage.getItem('user');
  }

}
